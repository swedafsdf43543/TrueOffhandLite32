package com.example.trueoffhand;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.client.registry.ClientRegistry;

import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChatComponentText;

import org.lwjgl.input.Keyboard;

@Mod(modid = "trueoffhand", name = "True Offhand Lite", version = "0.1")
public class TrueOffhandLite {

    public static KeyBinding useOffhandKey;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        useOffhandKey = new KeyBinding("Use Offhand", Keyboard.KEY_F, "TrueOffhandLite");
        ClientRegistry.registerKeyBinding(useOffhandKey);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        NetworkRegistry.INSTANCE.registerGuiHandler(this, null);
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        // Hook into other mods if needed
    }

    public static void useOffhand(EntityPlayer player) {
        ItemStack offhand = getOffhandItem(player);
        if (offhand != null) {
            player.addChatMessage(new ChatComponentText("[Offhand] Использован предмет: " + offhand.getDisplayName()));
        } else {
            player.addChatMessage(new ChatComponentText("[Offhand] Левая рука пуста."));
        }
    }

    public static ItemStack getOffhandItem(EntityPlayer player) {
        NBTTagCompound tag = player.getEntityData();
        if (tag.hasKey("OffhandItem")) {
            return ItemStack.loadItemStackFromNBT(tag.getCompoundTag("OffhandItem"));
        }
        return null;
    }

    public static void setOffhandItem(EntityPlayer player, ItemStack stack) {
        NBTTagCompound tag = player.getEntityData();
        NBTTagCompound itemTag = new NBTTagCompound();
        stack.writeToNBT(itemTag);
        tag.setTag("OffhandItem", itemTag);
    }
}
